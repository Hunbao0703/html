<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>普發現金</title>
    </head>
    <body>
        <h1>普發6000元補助領取平台</h1>
        <h2>輸入錯誤請重新輸入</h2>
        
        <form action="index.php">
            <input type="submit" value='上一頁'>
        </form>
        

    </body>
</html>