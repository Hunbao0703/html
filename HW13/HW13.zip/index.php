<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <title>大樂透彩券下注系統</title>
</head>
<html>
    <h1>大樂透彩券下注系統</h1>
    <form action="lottery.php" method="get">
        <a>請選擇您要下注的次數(最多10注)：</a><br>
        <input style="width: 10%;" type="number" max="10" min="1" placeholder="次數:" name="times">
        <input type="submit" value="下注"><br>
        <a>※每次下注時間系統會自動間隔3秒</a>
    </form>
</html>