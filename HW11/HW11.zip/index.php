<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>商品價格登陸系統</title>
    </head>
    <body>
        <h1>商品價格登陸系統</h1>
        <form action="goods.php" method="GET">
            總共需要登陸幾格商品: <input type="number" name="amount"><br>
            <input type="submit" value="送出">
        </form>

    </body>
</html>