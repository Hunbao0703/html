<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <title>校務系統</title>
</head>
<html>
    <h2>校務系統</h2>
    <form action="result.php" method="GET">
        姓名: <input type="text" name="name" placeholder="姓名"> 
        學號: <input type="text" name="account" placeholder="學號">
        <input type="submit" value="送出">
    </form>
</html>