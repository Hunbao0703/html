<!DOCTPYE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>學生資料管理系統-刪除資料</title>
		<style>*{font-family:"微軟正黑體";}</style>
	</head>
	<body>
		<center>
		<h1 align="center">學生資料管理系統 - 刪除資料</h1>
		<form action="db_delete.php" method="post">
			輸入所要修改的ID：<input type="number" name="id" required="required">
			
			<br>
			<input type="submit" value="刪除資料">			
		</form>
		</center>
	</body>
</html>

